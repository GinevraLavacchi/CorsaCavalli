/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package escorsacavalli;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author Ginevra
 */
public class Pannello extends JPanel implements ActionListener
{
    JTextField numero;
    JProgressBar barra;
    JLabel b,n;
    JButton bottone;
    public Pannello()
    {
        this.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.anchor = GridBagConstraints.CENTER;
        c.gridx=0;
        c.gridy=0;
        c.insets =  new Insets(0,0,0,0);
        numero=new JTextField(20);
        b=new JLabel("BENVENUTO!!");
        this.add(b,c);
        n = new JLabel("Quanti fantini parteciperanno?");
        c.gridy++;
        this.add(n,c);
        c.gridy++;
        this.add(numero,c);
        bottone=new Bottone();
        bottone.addActionListener(this);
        c.gridy++;
        this.add(bottone,c);
        barra=new JProgressBar(); 
        barra.setValue(0); 
        barra.setStringPainted(true);
        c.gridy++;
        this.add(barra,c);
        barra.setVisible(false);
    }
    
     @Override
    public void actionPerformed(ActionEvent e) {
        b.setVisible(false);
        n.setVisible(false);
        bottone.setVisible(false);
        numero.setVisible(false);
        barra.setVisible(true);
        aumento();
    }
    public void aumento()
    {
        for(int i=0;i<=100;i++)
        {
             barra.setValue(i); 
        }
        
    }
}